﻿using var game = new FinalProjectGame.Game1();
game.Run();
