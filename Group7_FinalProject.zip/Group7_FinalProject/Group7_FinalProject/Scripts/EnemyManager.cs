﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

public class EnemyManager
{
	public List<Vector2> Enemies = new List<Vector2>();
	public Texture2D Texture;
	private List<float> Speeds = new List<float>();
	private List<Rectangle> EnemyPlatforms = new List<Rectangle>();

	public void LoadContent(Texture2D texture, List<Rectangle> platforms)
	{
		Texture = texture;

		// Assign enemies to their respective platforms
		Enemies.Add(new Vector2(320, platforms[0].Y - texture.Height)); // Platform 1
		Speeds.Add(1f);
		EnemyPlatforms.Add(platforms[0]);

		Enemies.Add(new Vector2(720, platforms[1].Y - texture.Height)); // Platform 2
		Speeds.Add(-1f);
		EnemyPlatforms.Add(platforms[1]);

		Enemies.Add(new Vector2(1120, platforms[2].Y - texture.Height)); // Platform 3
		Speeds.Add(1f);
		EnemyPlatforms.Add(platforms[2]);

		Enemies.Add(new Vector2(1520, platforms[3].Y - texture.Height)); // Platform 4
		Speeds.Add(-1f);
		EnemyPlatforms.Add(platforms[3]);
	}

	public bool CheckCollision(Rectangle playerRect)
	{
		foreach (var enemy in Enemies)
		{
			Rectangle enemyRect = new Rectangle((int)enemy.X, (int)enemy.Y, Texture.Width, Texture.Height);
			if (playerRect.Intersects(enemyRect))
			{
				return true; // Collision detected
			}
		}
		return false; // No collision
	}

	public void Update(GameTime gameTime)
	{
		for (int i = 0; i < Enemies.Count; i++)
		{
			// Move enemies horizontally within their respective platforms
			Enemies[i] = new Vector2(Enemies[i].X + Speeds[i], Enemies[i].Y);

			// Reverse direction if enemy reaches the edge of its platform
			if (Enemies[i].X < EnemyPlatforms[i].Left || Enemies[i].X + Texture.Width > EnemyPlatforms[i].Right)
			{
				Speeds[i] *= -1; // Reverse direction
			}
		}
	}

	public void Draw(SpriteBatch spriteBatch)
	{
		foreach (var enemy in Enemies)
		{
			spriteBatch.Draw(Texture, enemy, Color.White);
		}
	}
}
