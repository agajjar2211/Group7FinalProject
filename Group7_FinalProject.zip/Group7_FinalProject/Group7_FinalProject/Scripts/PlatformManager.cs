﻿using Microsoft.Xna.Framework.Graphics;
using System;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group7_FinalProject.Scripts
{
	public class PlatformManager
	{
		public List<Rectangle> Platforms = new List<Rectangle>();
		public Texture2D Texture;

		public void LoadContent(Texture2D texture)
		{
			Texture = texture;

			// Base Platform: Positioned lower for a more natural player start
			Platforms.Add(new Rectangle(0, 520, 2000, 50)); // Long base platform

			// Floating Platforms: Reduce vertical gaps for easier jumping
			Platforms.Add(new Rectangle(300, 450, 200, 20)); // Platform 1
			Platforms.Add(new Rectangle(700, 400, 200, 20)); // Platform 2
			Platforms.Add(new Rectangle(1100, 350, 200, 20)); // Platform 3
			Platforms.Add(new Rectangle(1500, 300, 200, 20)); // Platform 4
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			foreach (var platform in Platforms)
			{
				spriteBatch.Draw(Texture, platform, Color.White);
			}
		}
	}
}
