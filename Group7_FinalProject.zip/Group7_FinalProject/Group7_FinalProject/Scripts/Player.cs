﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group7_FinalProject.Scripts
{
	public class Player
	{
		public Texture2D Texture;
		public Vector2 Position;
		public Vector2 Velocity;
		public bool IsJumping;

		private const float Gravity = 0.5f;        // Gravity to pull the player down
		private const float JumpStrength = -10f;  // Initial upward velocity when jumping

		public void LoadContent(Texture2D texture)
		{
			Texture = texture;
			Position = new Vector2(100, 400); // Starting position
			Velocity = Vector2.Zero;
			IsJumping = false;
		}

		public void Update(GameTime gameTime, List<Rectangle> platforms, int levelWidth)
		{
			KeyboardState state = Keyboard.GetState();

			// Horizontal movement
			if (state.IsKeyDown(Keys.Left)) Position.X -= 3f;
			if (state.IsKeyDown(Keys.Right)) Position.X += 3f;

			// Clamp player within level boundaries
			Position.X = MathHelper.Clamp(Position.X, 0, levelWidth - Texture.Width);

			// Jump logic
			if (state.IsKeyDown(Keys.Space) && !IsJumping)
			{
				Velocity.Y = JumpStrength;
				IsJumping = true;
			}

			// Apply gravity
			Velocity.Y += Gravity;
			Position += Velocity;

			// Check for platform collisions
			foreach (var platform in platforms)
			{
				Rectangle playerRect = new Rectangle((int)Position.X, (int)Position.Y, Texture.Width, Texture.Height);

				// Only land on the platform directly below the player
				if (playerRect.Bottom <= platform.Top + 5 && playerRect.Bottom >= platform.Top && Velocity.Y >= 0 &&
					playerRect.Right > platform.Left && playerRect.Left < platform.Right)
				{
					Position.Y = platform.Y - Texture.Height; // Land on the platform
					Velocity.Y = 0; // Reset vertical velocity
					IsJumping = false; // Allow jumping again
					break;
				}
			}

			// Prevent player from falling below the base platform
			if (Position.Y > platforms[0].Y - Texture.Height)
			{
				Position.Y = platforms[0].Y - Texture.Height;
				Velocity.Y = 0;
				IsJumping = false;
			}
		}
		public Rectangle GetBounds()
		{
			return new Rectangle((int)Position.X, (int)Position.Y, Texture.Width, Texture.Height);
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			spriteBatch.Draw(Texture, Position, Color.White);
		}
	}

}
