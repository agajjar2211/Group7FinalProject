﻿using Microsoft.Xna.Framework.Graphics;
using System;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group7_FinalProject.Scripts
{
	public class ScoreManager
	{
		public void Draw(SpriteBatch spriteBatch, SpriteFont font, int score)
		{
			spriteBatch.DrawString(font, $"Score: {score}", new Vector2(10, 10), Color.White);
		}
	}
}
