﻿using Microsoft.Xna.Framework.Graphics;
using System;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group7_FinalProject.Scripts
{
	public class BackgroundManager
	{
		public Texture2D Texture;

		public void LoadContent(Texture2D texture)
		{
			Texture = texture;
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			// Repeat the background horizontally to fill the level
			for (int x = 0; x < 2000; x += Texture.Width)
			{
				spriteBatch.Draw(Texture, new Rectangle(x, 0, Texture.Width, Texture.Height), Color.White);
			}
		}
	}
}
