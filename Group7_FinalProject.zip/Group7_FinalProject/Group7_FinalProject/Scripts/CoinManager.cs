﻿using Microsoft.Xna.Framework.Graphics;
using System;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group7_FinalProject.Scripts
{
	public class CoinManager
	{
		public List<Vector2> Coins = new List<Vector2>();
		public Texture2D Texture;

		public void LoadContent(Texture2D texture)
		{
			Texture = texture;

			// Coins placed on platforms
			Coins.Add(new Vector2(350, 420)); // Platform 1
			Coins.Add(new Vector2(750, 370)); // Platform 2
			Coins.Add(new Vector2(1150, 320)); // Platform 3
			Coins.Add(new Vector2(1550, 270)); // Platform 4
			Coins.Add(new Vector2(450, 470)); // Base platform
			Coins.Add(new Vector2(850, 470)); // Base platform
		}

		public void Update(Player player, ref int score)
		{
			Rectangle playerRect = new Rectangle((int)player.Position.X, (int)player.Position.Y, player.Texture.Width, player.Texture.Height);

			for (int i = 0; i < Coins.Count; i++)
			{
				Rectangle coinRect = new Rectangle((int)Coins[i].X, (int)Coins[i].Y, Texture.Width, Texture.Height);
				if (playerRect.Intersects(coinRect))
				{
					score++;
					Coins.RemoveAt(i); // Remove coin when collected
				}
			}
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			foreach (var coin in Coins)
			{
				spriteBatch.Draw(Texture, coin, Color.White);
			}
		}

	}

}
