﻿using Group7_FinalProject.Scripts;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Group7_FinalProject
{
	public class Game1 : Game
	{
		private GraphicsDeviceManager _graphics;
		private SpriteBatch _spriteBatch;

		private Player _player;
		private PlatformManager _platformManager;
		private CoinManager _coinManager;
		private EnemyManager _enemyManager;
		private BackgroundManager _backgroundManager;
		private ScoreManager _scoreManager;

		private int _score = 0;
		private bool _gameOver = false;
		private string _gameOverMessage = "";

		private SpriteFont _font;
		private Vector2 _cameraPosition;

		public Game1()
		{
			_graphics = new GraphicsDeviceManager(this)
			{
				PreferredBackBufferWidth = 800, // Width of the game window
				PreferredBackBufferHeight = 600 // Height of the game window
			};
			Content.RootDirectory = "Content";
			IsMouseVisible = true;
		}

		protected override void Initialize()
		{
			_player = new Player();
			_platformManager = new PlatformManager();
			_coinManager = new CoinManager();
			_enemyManager = new EnemyManager();
			_backgroundManager = new BackgroundManager();
			_scoreManager = new ScoreManager();

			_cameraPosition = Vector2.Zero;

			base.Initialize();
		}

		protected override void LoadContent()
		{
			_spriteBatch = new SpriteBatch(GraphicsDevice);

			_player.LoadContent(Content.Load<Texture2D>("guidoPlayer"));
			_platformManager.LoadContent(Content.Load<Texture2D>("platform"));
			_coinManager.LoadContent(Content.Load<Texture2D>("coin"));
			_enemyManager.LoadContent(Content.Load<Texture2D>("deathcapEnemy"));
			_backgroundManager.LoadContent(Content.Load<Texture2D>("background"));
			_font = Content.Load<SpriteFont>("DefaultFont");
		}

		protected override void Update(GameTime gameTime)
		{
			if (Keyboard.GetState().IsKeyDown(Keys.Escape))
				Exit();

			if (_gameOver)
				return;

			// Update player and restrict movement
			_player.Update(gameTime, _platformManager.Platforms, 2000);

			// Update coins
			_coinManager.Update(_player, ref _score);

			// Update enemies
			_enemyManager.Update(gameTime);

			// Check for collision with enemies
			if (_enemyManager.CheckCollision(_player.GetBounds()))
			{
				_gameOver = true;
				_gameOverMessage = "Game Over! You collided with an enemy.";
			}

			// Camera logic
			_cameraPosition.X = MathHelper.Clamp(_player.Position.X - 400, 0, 1200);

			base.Update(gameTime);
		}

		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.CornflowerBlue);

			_spriteBatch.Begin(transformMatrix: Matrix.CreateTranslation(-_cameraPosition.X, 0, 0));

			// Draw components
			_backgroundManager.Draw(_spriteBatch);
			_platformManager.Draw(_spriteBatch);
			_coinManager.Draw(_spriteBatch);
			_enemyManager.Draw(_spriteBatch);
			_player.Draw(_spriteBatch);
			_scoreManager.Draw(_spriteBatch, _font, _score);

			// Draw game-over message
			if (_gameOver)
			{
				_spriteBatch.DrawString(_font, _gameOverMessage, new Vector2(_cameraPosition.X + 200, 200), Color.Red);
			}

			_spriteBatch.End();

			base.Draw(gameTime);
		}


		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.CornflowerBlue);

			_spriteBatch.Begin(transformMatrix: Matrix.CreateTranslation(-_cameraPosition.X, 0, 0));

			// Draw components
			_backgroundManager.Draw(_spriteBatch);
			_platformManager.Draw(_spriteBatch);
			_coinManager.Draw(_spriteBatch);
			_enemyManager.Draw(_spriteBatch);
			_player.Draw(_spriteBatch);
			_scoreManager.Draw(_spriteBatch, _font, _score);

			// Draw game-over message
			if (_gameOver)
			{
				_spriteBatch.DrawString(_font, _gameOverMessage, new Vector2(_cameraPosition.X + 200, 200), Color.Red);
			}

			_spriteBatch.End();

			base.Draw(gameTime);
		}
	}
}
