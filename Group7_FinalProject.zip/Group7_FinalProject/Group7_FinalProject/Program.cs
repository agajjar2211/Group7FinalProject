﻿using var game = new Group7_FinalProject.Game1();
game.Run();
