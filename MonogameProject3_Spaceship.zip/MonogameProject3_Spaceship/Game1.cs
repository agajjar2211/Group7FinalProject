﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;

namespace MonogameProject3_Spaceship
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private int score;
        private Song backgroundmusic;

        Texture2D shipSprite;
        Texture2D asteroidSprite;
        Texture2D spaceSprite;
        SpriteFont gameFont;
        SpriteFont timerFont;
        
        Ship player = new Ship();
        List<Asteroid> asteroids = new List<Asteroid>();
        Random ra = new Random();


        // Timer variables
        private TimeSpan elapsedTime;
        private int secondsElapsed;
        private TimeSpan TimeElapsed;

        //Controller object
        Controller controller = new Controller();

        //Game State
        bool inGame = true;
        private string lastMessage = "";
            
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            _graphics.PreferredBackBufferWidth = 1200;
            _graphics.PreferredBackBufferHeight = 900;
            _graphics.ApplyChanges();

            //timer related
            elapsedTime = TimeSpan.Zero;
            secondsElapsed = 0;
            score = 0;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            shipSprite = Content.Load<Texture2D>("ship");
            asteroidSprite = Content.Load<Texture2D>("asteroid");
            spaceSprite = Content.Load<Texture2D>("space");
            gameFont = Content.Load<SpriteFont>("spaceFont");
            timerFont = Content.Load<SpriteFont>("timerFont");

          
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (inGame) 
            {
                //moment of player
                player.setRadius(shipSprite.Width / 2);
                player.updateShip(_graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);


                //planting new aestroids
                TimeElapsed += gameTime.ElapsedGameTime;
                if (TimeElapsed.TotalSeconds >= 2) 
                {
                    SpawnAestroid();
                    TimeElapsed = TimeSpan.Zero;
                }

                //updating aestroid 
                for (int i = asteroids.Count - 1; i >= 0; i--) 
                {
                    asteroids[i].updateAsteroid();

                    if (asteroids[i].position.X+ Asteroid.radius <0) 
                    {
                        score++;
                        asteroids.RemoveAt(i);
                    }
                }

                //checking collision 
                for(int i = 0; i < asteroids.Count; i++) 
                {
                    if (controller.didCollisionHappen(player, asteroids[i])) 
                    {
                        score -= 3;
                        asteroids.RemoveAt(i);
                        if (score < 0)
						{
							lastMessage = "Game Lost! SpaceShip hit by an aestroid";
                            inGame = false;
							
                            break;

						}
                       
                    }
                }

                //updating timmer every time
                secondsElapsed = controller.updateTime(gameTime);

                // game sccess
                if (secondsElapsed >= 15) 
                {
                    inGame = false;
                    lastMessage = $"Game Won! you surpassed {score} aestroids";
                }

            }
            base.Update(gameTime);
           
           
        }

        private void SpawnAestroid() 
        {
            int randomY = ra.Next(Asteroid.radius, _graphics.PreferredBackBufferHeight - Asteroid.radius);
    
             Vector2 startPosition = new Vector2(_graphics.PreferredBackBufferWidth + Asteroid.radius, randomY);

            int randomSpeed = ra.Next(2, 7);

            asteroids.Add(new Asteroid(startPosition, randomSpeed));
		}
        protected override void Draw(GameTime gameTime)
        {


            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            _spriteBatch.Begin();
            _spriteBatch.Draw(spaceSprite, new Vector2(0, 0), Color.White);
            //_spriteBatch.Draw(shipSprite, player.position, Color.White);//without centering the sprite
            _spriteBatch.Draw(shipSprite, new Vector2(player.position.X-shipSprite.Width/2, player.position.Y-shipSprite.Height/2), Color.White);//Using Offset and With Centering the sprite
            //_spriteBatch.Draw(asteroidSprite, new Vector2(ast1.position.X-Asteroid.radius , ast1.position.Y-Asteroid.radius), Color.White);

            //drawing aestroid
            foreach (var aestroid in asteroids)
            {
                _spriteBatch.Draw(asteroidSprite, new Vector2(aestroid.position.X - Asteroid.radius, aestroid.position.Y - Asteroid.radius), Color.White);

            }



            // Displaying Timer
            _spriteBatch.DrawString(timerFont, "Time: " + secondsElapsed, new Vector2(_graphics.PreferredBackBufferWidth / 2, 30), Color.White);


            // Displaying score 
            _spriteBatch.DrawString(timerFont, "Score:" + score, new Vector2(30, 30), Color.White);


            // Displaying Game Over Message
            if (!inGame)
            {
                _spriteBatch.DrawString(gameFont, lastMessage,  new Vector2(_graphics.PreferredBackBufferWidth / 2 - 350, _graphics.PreferredBackBufferHeight / 2), Color.White);
            }

            _spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
