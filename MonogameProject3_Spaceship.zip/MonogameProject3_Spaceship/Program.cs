﻿using var game = new MonogameProject3_Spaceship.Game1();
game.Run();
